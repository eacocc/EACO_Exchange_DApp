# EACO DEX 2025+ Interactive Gantt Package

This package contains:
- Interactive Gantt (frontend/public/gantt.html)
- Project skeleton (frontend, backend, ai, contracts, crosschain)
- docker-compose.yml

Open `frontend/public/gantt.html` in a browser to view the interactive roadmap.